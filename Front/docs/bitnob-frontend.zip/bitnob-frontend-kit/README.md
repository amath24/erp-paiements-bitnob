# Bitnob Frontend Kit (Person 2 – Frontend / UX)

React + Vite. Runs **today with mock data**, then switches to the real backend with one env variable.

## Run

```bash
npm install
npm run dev            # http://localhost:5173  (demo mode, no backend needed)
```

Real backend (Person 1's Express server, default http://localhost:3000):

```bash
VITE_USE_MOCK=false npm run dev
# another port?  VITE_API_TARGET=http://localhost:4000 VITE_USE_MOCK=false npm run dev
```

## What's inside

| Template | Pages | Route |
|---|---|---|
| Freelance / B2B | Dashboard (balance, KPIs, chart), Invoices (create + QR), public payment page | `/`, `/invoices`, `/pay/:id` |
| Remittance / Payout | Send money (live quote), Transfers (stepper tracking) | `/send`, `/transfers` |
| Cards / Budget | Virtual cards, fund, transactions, spending donut | `/cards` |
| BulkPay | CSV upload + validation + review + launch, batch list, batch detail + CSV export | `/bulkpay`, `/bulkpay/batches` |

## Re-skin for the real theme (hackathon day)

- `src/config.js` : app name, tagline, **which modules show in the sidebar**, supported countries and currencies.
- `src/styles.css` : colors are CSS variables at the top (`--accent`, ...).
- `src/api/mock.js` : fake data. `src/api/client.js` : the switch between mock and real.
- Pages live in `src/templates/*`. Copy the closest one and adapt it.

## API contract the backend must expose (all JSON under `/api`)

| Method + path | Body | Returns |
|---|---|---|
| `GET /summary` | | `{ balance, balance_currency, received, pending, invoice_count, daily:[{label,value}] }` |
| `GET /invoices` | | `[{ id, client, email, amount, currency, description, status, created_at }]` (status: `pending` / `paid` / `expired`) |
| `POST /invoices` | `{ client, email, amount, currency, description }` | `{ id, payment_url, lightning_invoice, ...invoice }` |
| `GET /invoices/:id` | | invoice + `lightning_invoice` + `payment_url` (the pay page polls this every 4 s) |
| `POST /transfers/quote` | `{ amount, country }` | `{ rate, fee, receive_currency, receive_amount }` |
| `GET /transfers` | | `[{ id, recipient, country, type, account, send_amount, receive_amount, receive_currency, fee, status, created_at }]` |
| `POST /transfers` | `{ amount, country, type, recipient, account }` | the created transfer |
| `GET /cards` | | `[{ id, label, last4, brand, balance, limit, status }]` |
| `POST /cards` | `{ label, limit }` | the created card |
| `POST /cards/:id/fund` | `{ amount }` | the updated card |
| `GET /cards/:id/transactions` | | `[{ id, merchant, category, amount, created_at }]` |
| `POST /bulk_payout` | `{ name, items:[{ name, phone, amount, currency, country }] }` | `{ id, ... }` |
| `GET /batches` | | `[{ id, name, created_at, status, count, success, failed, total }]` |
| `GET /batches/:id` | | batch + `items:[{ id, name, phone, amount, currency, country, status }]` (item status: `processing` / `success` / `failed`) |

Statuses drive the colored badges, so keep these exact words. The "Simulate payment (demo)" button only exists in mock mode; in real mode the Bitnob webhook must flip the invoice to `paid`.

## Notes

- The UI is in English because the hackathon and its judges are English-speaking.
- QR codes encode the Lightning invoice (`qrcode.react`).
- CSV format for BulkPay: `name,phone,amount,currency,country` (see "Use sample data" in the UI).
