import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// In real mode (VITE_USE_MOCK=false) every /api/* call is proxied to the backend.
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: { '/api': { target: process.env.VITE_API_TARGET || 'http://localhost:3000', changeOrigin: true } },
  },
});
