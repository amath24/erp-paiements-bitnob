// One place to re-skin the whole kit once the hackathon theme is known.
// Remove a module from `modules` to hide it from the sidebar.
export const APP_NAME = 'PayLink Africa';
export const TAGLINE = 'Bitcoin-powered payments, built on Bitnob';

export const modules = [
  {
    group: 'Freelance / B2B',
    items: [
      { to: '/', label: 'Dashboard', end: true },
      { to: '/invoices', label: 'Invoices' },
    ],
  },
  {
    group: 'Remittance',
    items: [
      { to: '/send', label: 'Send money' },
      { to: '/transfers', label: 'Transfers' },
    ],
  },
  {
    group: 'Cards / Budget',
    items: [{ to: '/cards', label: 'Virtual cards' }],
  },
  {
    group: 'BulkPay',
    items: [
      { to: '/bulkpay', label: 'New batch', end: true },
      { to: '/bulkpay/batches', label: 'Batches' },
    ],
  },
];

export const COUNTRIES = {
  Nigeria: { currency: 'NGN', rate: 1550 },
  Ghana: { currency: 'GHS', rate: 15.5 },
  Kenya: { currency: 'KES', rate: 129 },
  Senegal: { currency: 'XOF', rate: 610 },
  Uganda: { currency: 'UGX', rate: 3700 },
  Rwanda: { currency: 'RWF', rate: 1400 },
};

export const INVOICE_CURRENCIES = ['USD', 'NGN', 'GHS', 'KES', 'XOF'];
