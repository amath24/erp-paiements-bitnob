import { NavLink, Route, Routes } from 'react-router-dom';
import { APP_NAME, TAGLINE, modules } from './config.js';
import { isMock } from './api/client.js';
import Dashboard from './templates/freelance/Dashboard.jsx';
import Invoices from './templates/freelance/Invoices.jsx';
import PayPage from './templates/freelance/PayPage.jsx';
import Send from './templates/remittance/Send.jsx';
import Transfers from './templates/remittance/Transfers.jsx';
import Cards from './templates/cards/Cards.jsx';
import BulkNew from './templates/bulkpay/BulkNew.jsx';
import { BatchList, BatchDetail } from './templates/bulkpay/Batches.jsx';

function Shell({ children }) {
  const [first, ...rest] = APP_NAME.split(' ');
  return (
    <div className="shell">
      <aside className="side">
        <div className="brand">{first} <b>{rest.join(' ')}</b></div>
        <div className="tag">{TAGLINE}</div>
        {modules.map((g) => (
          <div className="nav-group" key={g.group}>
            <h4>{g.group}</h4>
            {g.items.map((i) => (
              <NavLink key={i.to} to={i.to} end={i.end}>{i.label}</NavLink>
            ))}
          </div>
        ))}
        <div className="mode">{isMock ? 'Demo mode · mock data' : 'Live · Bitnob sandbox'}</div>
      </aside>
      <main className="main">{children}</main>
    </div>
  );
}

export default function App() {
  return (
    <Routes>
      <Route path="/pay/:id" element={<PayPage />} />
      <Route
        path="*"
        element={
          <Shell>
            <Routes>
              <Route path="/" element={<Dashboard />} />
              <Route path="/invoices" element={<Invoices />} />
              <Route path="/send" element={<Send />} />
              <Route path="/transfers" element={<Transfers />} />
              <Route path="/cards" element={<Cards />} />
              <Route path="/bulkpay" element={<BulkNew />} />
              <Route path="/bulkpay/batches" element={<BatchList />} />
              <Route path="/bulkpay/batches/:id" element={<BatchDetail />} />
            </Routes>
          </Shell>
        }
      />
    </Routes>
  );
}
