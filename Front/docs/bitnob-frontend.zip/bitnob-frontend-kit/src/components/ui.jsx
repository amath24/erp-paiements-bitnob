import { useEffect } from 'react';

export const PageHeader = ({ title, subtitle, action }) => (
  <div className="page-h">
    <div>
      <h1>{title}</h1>
      {subtitle && <p className="muted">{subtitle}</p>}
    </div>
    {action}
  </div>
);

export const Card = ({ title, action, children, className = '' }) => (
  <section className={`card ${className}`}>
    {(title || action) && (
      <header className="card-h">
        <h3>{title}</h3>
        {action}
      </header>
    )}
    {children}
  </section>
);

export const StatCard = ({ label, value, hint }) => (
  <div className="card stat">
    <span className="muted">{label}</span>
    <strong>{value}</strong>
    {hint && <small className="muted">{hint}</small>}
  </div>
);

const TONE = {
  paid: 'ok', success: 'ok', completed: 'ok', active: 'ok',
  pending: 'warn', processing: 'warn', completed_with_errors: 'warn',
  expired: 'bad', failed: 'bad', frozen: 'bad',
};
export const Badge = ({ status }) => <span className={`badge ${TONE[status] || ''}`}>{String(status).replace(/_/g, ' ')}</span>;

export const Loading = ({ text = 'Loading…' }) => <div className="muted pad">{text}</div>;
export const Empty = ({ text }) => <div className="muted pad center">{text}</div>;
export const ErrorBox = ({ error }) => <div className="alert bad">{error?.message || 'Something went wrong'}</div>;

export function Modal({ title, onClose, children }) {
  useEffect(() => {
    const h = (e) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, [onClose]);
  return (
    <div className="overlay" onClick={onClose}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        <header className="card-h">
          <h3>{title}</h3>
          <button className="icon" onClick={onClose} aria-label="Close">✕</button>
        </header>
        {children}
      </div>
    </div>
  );
}

export const Field = ({ label, children, hint }) => (
  <label className="field">
    <span>{label}</span>
    {children}
    {hint && <small className="muted">{hint}</small>}
  </label>
);

export function BarChart({ data = [] }) {
  if (!data.length) return <Empty text="No data yet" />;
  const max = Math.max(...data.map((d) => d.value), 1);
  return (
    <div className="bars">
      {data.map((d) => (
        <div className="bar-col" key={d.label} title={`${d.label}: ${d.value}`}>
          <div className="bar" style={{ height: `${(d.value / max) * 100}%` }} />
          <span>{d.label}</span>
        </div>
      ))}
    </div>
  );
}

const PALETTE = ['#f7931a', '#2563eb', '#16a34a', '#9333ea', '#dc2626', '#0891b2'];
export function Donut({ data = [] }) {
  const total = data.reduce((s, d) => s + d.value, 0);
  if (!total) return <Empty text="No spending yet" />;
  let acc = 0;
  return (
    <div className="donut-wrap">
      <svg viewBox="0 0 42 42" className="donut">
        <circle cx="21" cy="21" r="15.915" fill="none" stroke="#eef0f4" strokeWidth="6" />
        {data.map((d, i) => {
          const pct = (d.value / total) * 100;
          const el = (
            <circle key={d.label} cx="21" cy="21" r="15.915" fill="none" stroke={PALETTE[i % PALETTE.length]} strokeWidth="6"
              strokeDasharray={`${pct} ${100 - pct}`} strokeDashoffset={25 - acc} />
          );
          acc += pct;
          return el;
        })}
      </svg>
      <ul className="legend">
        {data.map((d, i) => (
          <li key={d.label}>
            <i style={{ background: PALETTE[i % PALETTE.length] }} /> {d.label}
            <b>{Math.round((d.value / total) * 100)}%</b>
          </li>
        ))}
      </ul>
    </div>
  );
}

export function Stepper({ steps, current, failed }) {
  return (
    <ol className="stepper">
      {steps.map((s, i) => (
        <li key={s} className={failed && i === current ? 'bad' : i < current ? 'done' : i === current ? 'now' : ''}>
          <i>{i < current ? '✓' : i + 1}</i>
          {s}
        </li>
      ))}
    </ol>
  );
}
