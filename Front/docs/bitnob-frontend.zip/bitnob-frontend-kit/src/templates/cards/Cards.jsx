import { useEffect, useState } from 'react';
import { api } from '../../api/client.js';
import { useAsync } from '../../lib/hooks.js';
import { money, dateTime } from '../../lib/format.js';
import { PageHeader, Card, Badge, Modal, Field, Donut, Loading, Empty, ErrorBox } from '../../components/ui.jsx';

function NewCardModal({ onClose, onDone }) {
  const [form, setForm] = useState({ label: '', limit: 500 });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);
  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    try {
      await api.createCard(form);
      onDone();
      onClose();
    } catch (err) {
      setError(err);
      setBusy(false);
    }
  };
  return (
    <Modal title="New virtual card" onClose={onClose}>
      {error && <ErrorBox error={error} />}
      <form onSubmit={submit}>
        <Field label="Card name"><input required value={form.label} onChange={(e) => setForm({ ...form, label: e.target.value })} placeholder="Marketing" /></Field>
        <Field label="Spending limit (USD)"><input type="number" min="10" required value={form.limit} onChange={(e) => setForm({ ...form, limit: e.target.value })} /></Field>
        <div className="actions">
          <button type="button" className="btn ghost" onClick={onClose}>Cancel</button>
          <button className="btn" disabled={busy}>{busy ? 'Creating…' : 'Create card'}</button>
        </div>
      </form>
    </Modal>
  );
}

function FundModal({ card, onClose, onDone }) {
  const [amount, setAmount] = useState(100);
  const [busy, setBusy] = useState(false);
  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    await api.fundCard(card.id, amount);
    onDone();
    onClose();
  };
  return (
    <Modal title={`Fund “${card.label}”`} onClose={onClose}>
      <form onSubmit={submit}>
        <Field label="Amount (USD)" hint="Funded from your wallet balance"><input type="number" min="1" required value={amount} onChange={(e) => setAmount(e.target.value)} /></Field>
        <div className="actions">
          <button type="button" className="btn ghost" onClick={onClose}>Cancel</button>
          <button className="btn" disabled={busy}>{busy ? 'Funding…' : 'Fund card'}</button>
        </div>
      </form>
    </Modal>
  );
}

export default function Cards() {
  const cards = useAsync(() => api.listCards());
  const [selected, setSelected] = useState(null);
  const [modal, setModal] = useState(null); // 'new' | 'fund'

  useEffect(() => {
    if (!selected && cards.data?.length) setSelected(cards.data[0].id);
  }, [cards.data, selected]);

  const tx = useAsync(() => (selected ? api.listCardTransactions(selected) : Promise.resolve([])), [selected]);
  const card = cards.data?.find((c) => c.id === selected);

  const byCategory = Object.entries(
    (tx.data || []).reduce((acc, t) => ({ ...acc, [t.category]: (acc[t.category] || 0) + t.amount }), {})
  ).map(([label, value]) => ({ label, value }));

  return (
    <>
      <PageHeader title="Virtual cards" subtitle="Create cards, fund them and watch spending by category" action={<button className="btn" onClick={() => setModal('new')}>+ New card</button>} />
      {cards.error && <ErrorBox error={cards.error} />}
      {cards.loading && !cards.data ? (
        <Loading />
      ) : (
        <div className="stack">
          <div className="cards-row">
            {cards.data.map((c) => (
              <div key={c.id} className={`vcard ${c.id === selected ? 'sel' : ''}`} onClick={() => setSelected(c.id)}>
                <span className="brand-tag">{c.brand}</span>
                <div style={{ opacity: .8 }}>{c.label}</div>
                <div className="num-card">•••• •••• •••• {c.last4}</div>
                <div className="bal">{money(c.balance)}</div>
                <div className="progress"><div style={{ width: `${Math.min(100, (c.balance / c.limit) * 100)}%` }} /></div>
                <small style={{ opacity: .7 }}>Limit {money(c.limit)}</small>
              </div>
            ))}
          </div>

          {card && (
            <div className="grid g2">
              <Card title={`Transactions · ${card.label}`} action={<div><Badge status={card.status} /> <button className="btn sm" onClick={() => setModal('fund')}>Fund</button></div>}>
                {tx.loading ? <Loading /> : !tx.data?.length ? <Empty text="No transactions yet." /> : (
                  <table>
                    <tbody>
                      {tx.data.map((t) => (
                        <tr key={t.id}>
                          <td><b>{t.merchant}</b><div className="muted">{t.category} · {dateTime(t.created_at)}</div></td>
                          <td className="num">−{money(t.amount)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
              </Card>
              <Card title="Spending by category"><Donut data={byCategory} /></Card>
            </div>
          )}
        </div>
      )}
      {modal === 'new' && <NewCardModal onClose={() => setModal(null)} onDone={cards.reload} />}
      {modal === 'fund' && card && <FundModal card={card} onClose={() => setModal(null)} onDone={cards.reload} />}
    </>
  );
}
