import { Link, useParams } from 'react-router-dom';
import { api } from '../../api/client.js';
import { useAsync, useInterval } from '../../lib/hooks.js';
import { money, dateTime, downloadCsv } from '../../lib/format.js';
import { PageHeader, Card, StatCard, Badge, Donut, Loading, Empty, ErrorBox } from '../../components/ui.jsx';

export function BatchList() {
  const { data, loading, error, reload } = useAsync(() => api.listBatches());
  useInterval(() => data?.some((b) => b.status === 'processing') && reload(), 4000);

  return (
    <>
      <PageHeader title="Batches" subtitle="Every bulk payout and its status" action={<Link className="btn" to="/bulkpay">+ New batch</Link>} />
      {error && <ErrorBox error={error} />}
      <Card>
        {loading && !data ? <Loading /> : !data?.length ? <Empty text="No batches yet." /> : (
          <table>
            <thead><tr><th>Batch</th><th>Created</th><th className="num">People</th><th className="num">Success</th><th className="num">Failed</th><th>Status</th></tr></thead>
            <tbody>
              {data.map((b) => (
                <tr key={b.id}>
                  <td><Link to={`/bulkpay/batches/${b.id}`}><b>{b.name}</b></Link></td>
                  <td className="muted">{dateTime(b.created_at)}</td>
                  <td className="num">{b.count}</td>
                  <td className="num">{b.success}</td>
                  <td className="num">{b.failed}</td>
                  <td><Badge status={b.status} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </Card>
    </>
  );
}

export function BatchDetail() {
  const { id } = useParams();
  const { data: b, loading, error, reload } = useAsync(() => api.getBatch(id), [id]);
  useInterval(() => b?.status === 'processing' && reload(), 2000);

  if (loading && !b) return <Loading />;
  if (error) return <ErrorBox error={error} />;
  if (!b) return null;

  const byCountry = Object.entries(b.items.reduce((a, i) => ({ ...a, [i.country]: (a[i.country] || 0) + 1 }), {})).map(([label, value]) => ({ label, value }));
  const done = b.success + b.failed;
  const pct = Math.round((done / b.count) * 100);

  return (
    <>
      <PageHeader
        title={b.name}
        subtitle={`Created ${dateTime(b.created_at)}`}
        action={
          <button className="btn ghost" onClick={() => downloadCsv(`${b.name.replace(/\s+/g, '_')}_report.csv`, b.items.map(({ name, phone, amount, currency, country, status }) => ({ name, phone, amount, currency, country, status })))}>
            Export report (CSV)
          </button>
        }
      />
      <div className="stack">
        <div className="grid g4">
          <StatCard label="Status" value={<Badge status={b.status} />} hint={`${pct}% processed`} />
          <StatCard label="Beneficiaries" value={b.count} />
          <StatCard label="Successful" value={b.success} />
          <StatCard label="Failed" value={b.failed} />
        </div>
        <div className="progress"><div style={{ width: `${pct}%` }} /></div>
        <div className="grid g2">
          <Card title="Payouts">
            <div className="scroll">
              <table>
                <thead><tr><th>Name</th><th>Country</th><th className="num">Amount</th><th>Status</th></tr></thead>
                <tbody>
                  {b.items.map((i) => (
                    <tr key={i.id}>
                      <td><b>{i.name}</b><div className="muted">{i.phone}</div></td>
                      <td>{i.country}</td>
                      <td className="num">{money(i.amount, i.currency)}</td>
                      <td><Badge status={i.status} /></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
          <Card title="By country"><Donut data={byCountry} /></Card>
        </div>
      </div>
    </>
  );
}
