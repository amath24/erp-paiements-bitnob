import { useMemo, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../../api/client.js';
import { parseBeneficiaries, SAMPLE_CSV, estimateFee } from '../../lib/csv.js';
import { money } from '../../lib/format.js';
import { PageHeader, Card, Field, StatCard, ErrorBox } from '../../components/ui.jsx';

export default function BulkNew() {
  const nav = useNavigate();
  const fileRef = useRef(null);
  const [name, setName] = useState('');
  const [text, setText] = useState('');
  const [over, setOver] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);

  const rows = useMemo(() => parseBeneficiaries(text), [text]);
  const valid = rows.filter((r) => !r.errors.length);
  const invalid = rows.length - valid.length;

  const totals = useMemo(() => {
    const byCur = {};
    valid.forEach((r) => (byCur[r.currency] = (byCur[r.currency] || 0) + r.amount));
    return byCur;
  }, [valid]);
  const fees = valid.reduce((s, r) => s + estimateFee(r.amount), 0);
  const countries = new Set(valid.map((r) => r.country)).size;

  const readFile = (file) => file && file.text().then(setText);

  const launch = async () => {
    setBusy(true);
    setError(null);
    try {
      const b = await api.createBatch({
        name,
        items: valid.map(({ name, phone, amount, currency, country }) => ({ name, phone, amount, currency, country })),
      });
      nav(`/bulkpay/batches/${b.id}`);
    } catch (err) {
      setError(err);
      setBusy(false);
    }
  };

  return (
    <>
      <PageHeader title="New bulk payout" subtitle="Upload a CSV, review the summary, pay everyone in one click" />
      <div className="stack">
        <Card title="1 · Beneficiaries">
          <Field label="Batch name"><input value={name} onChange={(e) => setName(e.target.value)} placeholder="Delivery riders – October" /></Field>
          <div
            className={`drop ${over ? 'over' : ''}`}
            onDragOver={(e) => { e.preventDefault(); setOver(true); }}
            onDragLeave={() => setOver(false)}
            onDrop={(e) => { e.preventDefault(); setOver(false); readFile(e.dataTransfer.files[0]); }}
          >
            <p style={{ margin: '0 0 8px' }}>Drag a CSV here, or</p>
            <button className="btn ghost" onClick={() => fileRef.current.click()}>Choose file</button>{' '}
            <button className="btn ghost" onClick={() => setText(SAMPLE_CSV)}>Use sample data</button>
            <input ref={fileRef} type="file" accept=".csv,text/csv" hidden onChange={(e) => readFile(e.target.files[0])} />
            <p className="muted" style={{ margin: '8px 0 0' }}>Columns: name, phone, amount, currency, country</p>
          </div>
          <Field label="Or paste CSV"><textarea value={text} onChange={(e) => setText(e.target.value)} spellCheck={false} /></Field>
        </Card>

        {rows.length > 0 && (
          <>
            <Card title="2 · Review">
              <div className="grid g4" style={{ marginBottom: 16 }}>
                <StatCard label="Beneficiaries" value={valid.length} hint={invalid ? `${invalid} row(s) with errors` : 'All rows valid'} />
                <StatCard label="Countries" value={countries} />
                <StatCard label="Total" value={Object.entries(totals).map(([c, v]) => money(v, c)).join(' + ') || '—'} />
                <StatCard label="Estimated fees" value={Object.keys(totals).length === 1 ? money(fees, Object.keys(totals)[0]) : '≈ 1%'} hint="≈ 1% of volume" />
              </div>
              {invalid > 0 && <div className="alert warn">Rows with errors are skipped. Fix them in the CSV or continue with the valid rows.</div>}
              <div className="scroll">
                <table>
                  <thead><tr><th>#</th><th>Name</th><th>Phone / account</th><th>Country</th><th className="num">Amount</th><th>Check</th></tr></thead>
                  <tbody>
                    {rows.map((r) => (
                      <tr key={r.row} className={r.errors.length ? 'err' : ''}>
                        <td className="muted">{r.row}</td>
                        <td>{r.name}</td>
                        <td>{r.phone}</td>
                        <td>{r.country}</td>
                        <td className="num">{r.amount ? `${r.amount.toLocaleString()} ${r.currency}` : '—'}</td>
                        <td>{r.errors.length ? <span className="badge bad">{r.errors.join(' · ')}</span> : <span className="badge ok">OK</span>}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Card>
            <Card title="3 · Launch">
              {error && <ErrorBox error={error} />}
              <div className="actions" style={{ marginTop: 0 }}>
                <button className="btn" disabled={busy || !valid.length} onClick={launch}>
                  {busy ? 'Sending…' : `Pay ${valid.length} beneficiaries`}
                </button>
              </div>
            </Card>
          </>
        )}
      </div>
    </>
  );
}
