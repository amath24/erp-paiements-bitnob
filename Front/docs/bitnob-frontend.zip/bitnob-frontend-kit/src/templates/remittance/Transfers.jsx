import { Link } from 'react-router-dom';
import { api } from '../../api/client.js';
import { useAsync, useInterval } from '../../lib/hooks.js';
import { money, dateTime } from '../../lib/format.js';
import { PageHeader, Card, Badge, Stepper, Loading, Empty, ErrorBox } from '../../components/ui.jsx';

const STEPS = ['Quoted', 'Initiated', 'Sent', 'Delivered'];
const stepOf = (s) => (s === 'completed' ? 4 : s === 'processing' ? 2 : s === 'failed' ? 2 : 1);

export default function Transfers() {
  const { data, loading, error, reload } = useAsync(() => api.listTransfers());
  useInterval(() => data?.some((t) => t.status === 'processing') && reload(), 4000);

  return (
    <>
      <PageHeader title="Transfers" subtitle="Track every transfer from quote to delivery" action={<Link className="btn" to="/send">+ Send money</Link>} />
      {error && <ErrorBox error={error} />}
      {loading && !data ? (
        <Loading />
      ) : !data?.length ? (
        <Card><Empty text="No transfers yet." /></Card>
      ) : (
        <div className="stack">
          {data.map((t) => (
            <Card key={t.id}>
              <div className="row" style={{ alignItems: 'center' }}>
                <div>
                  <b>{t.recipient}</b>
                  <div className="muted">{t.country} · {t.type === 'bank' ? 'Bank' : 'Mobile money'} · {t.account}</div>
                  <div className="muted">{dateTime(t.created_at)}</div>
                </div>
                <div className="num">
                  <div>{money(t.send_amount)} → <b>{money(t.receive_amount, t.receive_currency)}</b></div>
                  <div className="muted">Fee {money(t.fee)}</div>
                </div>
                <div style={{ flex: 'none' }}><Badge status={t.status} /></div>
              </div>
              <div style={{ marginTop: 14 }}>
                <Stepper steps={STEPS} current={stepOf(t.status)} failed={t.status === 'failed'} />
              </div>
            </Card>
          ))}
        </div>
      )}
    </>
  );
}
