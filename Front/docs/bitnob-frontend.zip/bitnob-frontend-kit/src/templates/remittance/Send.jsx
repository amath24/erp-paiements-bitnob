import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../../api/client.js';
import { COUNTRIES } from '../../config.js';
import { money } from '../../lib/format.js';
import { PageHeader, Card, Field, ErrorBox } from '../../components/ui.jsx';

export default function Send() {
  const nav = useNavigate();
  const [form, setForm] = useState({ amount: 100, country: 'Nigeria', type: 'mobile_money', recipient: '', account: '' });
  const [quote, setQuote] = useState(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  // Live quote whenever amount or country changes.
  useEffect(() => {
    const amount = Number(form.amount);
    if (!amount || amount <= 0) return setQuote(null);
    let alive = true;
    const t = setTimeout(() => api.quoteTransfer({ amount, country: form.country }).then((q) => alive && setQuote(q)).catch(() => {}), 250);
    return () => {
      alive = false;
      clearTimeout(t);
    };
  }, [form.amount, form.country]);

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await api.createTransfer({ ...form, amount: Number(form.amount) });
      nav('/transfers');
    } catch (err) {
      setError(err);
      setBusy(false);
    }
  };

  return (
    <>
      <PageHeader title="Send money" subtitle="Pay anyone in Africa to mobile money or bank, funded in USD / BTC" />
      <div className="grid g2">
        <Card>
          {error && <ErrorBox error={error} />}
          <form onSubmit={submit}>
            <Field label="You send (USD)"><input type="number" min="1" step="0.01" required value={form.amount} onChange={set('amount')} /></Field>
            <div className="row">
              <Field label="Destination country">
                <select value={form.country} onChange={set('country')}>
                  {Object.keys(COUNTRIES).map((c) => <option key={c}>{c}</option>)}
                </select>
              </Field>
              <Field label="Payout method">
                <select value={form.type} onChange={set('type')}>
                  <option value="mobile_money">Mobile money</option>
                  <option value="bank">Bank account</option>
                </select>
              </Field>
            </div>
            <Field label="Recipient name"><input required value={form.recipient} onChange={set('recipient')} placeholder="Amina Yusuf" /></Field>
            <Field label={form.type === 'mobile_money' ? 'Phone number' : 'Account number'}>
              <input required value={form.account} onChange={set('account')} placeholder={form.type === 'mobile_money' ? '+234…' : 'Account number'} />
            </Field>
            <div className="actions"><button className="btn" disabled={busy || !quote}>{busy ? 'Sending…' : 'Send money'}</button></div>
          </form>
        </Card>
        <Card title="Summary">
          {!quote ? (
            <p className="muted">Enter an amount to see the exchange rate and fees.</p>
          ) : (
            <>
              <div className="summary-line"><span className="muted">Rate</span><span>1 USD = {quote.rate} {quote.receive_currency}</span></div>
              <div className="summary-line"><span className="muted">Fee</span><span>{money(quote.fee)}</span></div>
              <div className="summary-line"><span className="muted">You send</span><span>{money(form.amount)}</span></div>
              <div className="summary-line total"><span>Recipient gets</span><span>{money(quote.receive_amount, quote.receive_currency)}</span></div>
              <p className="muted" style={{ marginTop: 14 }}>Powered by Bitnob. Estimated delivery: a few minutes.</p>
            </>
          )}
        </Card>
      </div>
    </>
  );
}
