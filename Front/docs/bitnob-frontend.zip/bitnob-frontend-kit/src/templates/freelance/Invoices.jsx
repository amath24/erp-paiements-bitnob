import { useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { QRCodeSVG } from 'qrcode.react';
import { api } from '../../api/client.js';
import { INVOICE_CURRENCIES } from '../../config.js';
import { useAsync } from '../../lib/hooks.js';
import { money, dateTime } from '../../lib/format.js';
import { PageHeader, Card, Badge, Modal, Field, Loading, Empty, ErrorBox } from '../../components/ui.jsx';

function CreateInvoiceModal({ onClose, onCreated }) {
  const [form, setForm] = useState({ client: '', email: '', amount: '', currency: 'USD', description: '' });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);
  const [created, setCreated] = useState(null);
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      setCreated(await api.createInvoice(form));
      onCreated();
    } catch (err) {
      setError(err);
    } finally {
      setBusy(false);
    }
  };

  if (created) {
    return (
      <Modal title="Invoice created" onClose={onClose}>
        <div className="qr"><QRCodeSVG value={created.lightning_invoice || created.payment_url} size={190} /></div>
        <p className="muted center">Scan with any Lightning wallet, or share the payment link.</p>
        <Field label="Payment link">
          <input readOnly value={created.payment_url} onFocus={(e) => e.target.select()} />
        </Field>
        <Field label="Lightning invoice">
          <div className="mono">{created.lightning_invoice}</div>
        </Field>
        <div className="actions">
          <button className="btn ghost" onClick={() => navigator.clipboard?.writeText(created.payment_url)}>Copy link</button>
          <Link className="btn" to={`/pay/${created.id}`} target="_blank">Open payment page</Link>
        </div>
      </Modal>
    );
  }

  return (
    <Modal title="New invoice" onClose={onClose}>
      {error && <ErrorBox error={error} />}
      <form onSubmit={submit}>
        <Field label="Client name"><input required value={form.client} onChange={set('client')} placeholder="Acme Ltd" /></Field>
        <Field label="Client email"><input type="email" required value={form.email} onChange={set('email')} placeholder="billing@acme.com" /></Field>
        <div className="row">
          <Field label="Amount"><input type="number" min="1" step="0.01" required value={form.amount} onChange={set('amount')} /></Field>
          <Field label="Currency">
            <select value={form.currency} onChange={set('currency')}>
              {INVOICE_CURRENCIES.map((c) => <option key={c}>{c}</option>)}
            </select>
          </Field>
        </div>
        <Field label="Description"><input value={form.description} onChange={set('description')} placeholder="Logo design" /></Field>
        <div className="actions">
          <button type="button" className="btn ghost" onClick={onClose}>Cancel</button>
          <button className="btn" disabled={busy}>{busy ? 'Creating…' : 'Create invoice'}</button>
        </div>
      </form>
    </Modal>
  );
}

export default function Invoices() {
  const [params, setParams] = useSearchParams();
  const [open, setOpen] = useState(params.get('new') === '1');
  const { data, loading, error, reload } = useAsync(() => api.listInvoices());

  const close = () => {
    setOpen(false);
    if (params.get('new')) setParams({});
  };

  return (
    <>
      <PageHeader title="Invoices" subtitle="Create payment links and track who has paid" action={<button className="btn" onClick={() => setOpen(true)}>+ Create invoice</button>} />
      {error && <ErrorBox error={error} />}
      <Card>
        {loading || !data ? (
          <Loading />
        ) : data.length === 0 ? (
          <Empty text="No invoices yet. Create your first one." />
        ) : (
          <div className="scroll">
            <table>
              <thead>
                <tr><th>Client</th><th>Description</th><th>Date</th><th className="num">Amount</th><th>Status</th><th /></tr>
              </thead>
              <tbody>
                {data.map((i) => (
                  <tr key={i.id}>
                    <td><b>{i.client}</b><div className="muted">{i.email}</div></td>
                    <td>{i.description || '—'}</td>
                    <td className="muted">{dateTime(i.created_at)}</td>
                    <td className="num">{money(i.amount, i.currency)}</td>
                    <td><Badge status={i.status} /></td>
                    <td><Link className="btn ghost sm" to={`/pay/${i.id}`} target="_blank">Payment page</Link></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
      {open && <CreateInvoiceModal onClose={close} onCreated={reload} />}
    </>
  );
}
