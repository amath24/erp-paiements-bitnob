import { useState } from 'react';
import { useParams } from 'react-router-dom';
import { QRCodeSVG } from 'qrcode.react';
import { api, isMock } from '../../api/client.js';
import { useAsync, useInterval } from '../../lib/hooks.js';
import { money } from '../../lib/format.js';
import { Badge, Loading, ErrorBox } from '../../components/ui.jsx';
import { APP_NAME } from '../../config.js';

// Public page the client opens from the payment link (no sidebar).
export default function PayPage() {
  const { id } = useParams();
  const { data: inv, loading, error, reload } = useAsync(() => api.getInvoice(id), [id]);
  const [copied, setCopied] = useState(false);

  // Poll until the Bitnob webhook marks the invoice as paid.
  useInterval(() => inv?.status === 'pending' && reload(), 4000);

  return (
    <div className="pay-page">
      <div className="card pay-box">
        <div className="brand" style={{ color: '#111' }}>{APP_NAME.split(' ')[0]}<b>{APP_NAME.split(' ').slice(1).join(' ') && ' ' + APP_NAME.split(' ').slice(1).join(' ')}</b></div>
        {error && <ErrorBox error={error} />}
        {loading && !inv ? (
          <Loading />
        ) : inv ? (
          <>
            <p className="muted">{inv.client ? `Payment to ${inv.client}` : 'Payment request'}{inv.description ? ` · ${inv.description}` : ''}</p>
            <div className="pay-amount">{money(inv.amount, inv.currency)}</div>
            <Badge status={inv.status} />
            {inv.status === 'paid' ? (
              <div className="alert ok" style={{ marginTop: 18 }}>Payment received. Thank you!</div>
            ) : inv.status === 'expired' ? (
              <div className="alert bad" style={{ marginTop: 18 }}>This invoice has expired.</div>
            ) : (
              <>
                <div className="qr" style={{ margin: '18px 0 12px' }}>
                  <QRCodeSVG value={inv.lightning_invoice} size={200} />
                </div>
                <p className="muted">Scan with a Lightning wallet. Waiting for payment…</p>
                <div className="mono" style={{ margin: '8px 0' }}>{inv.lightning_invoice}</div>
                <div className="actions" style={{ justifyContent: 'center' }}>
                  <button className="btn ghost" onClick={() => { navigator.clipboard?.writeText(inv.lightning_invoice); setCopied(true); }}>
                    {copied ? 'Copied ✓' : 'Copy invoice'}
                  </button>
                  {isMock && (
                    <button className="btn" onClick={async () => { await api.simulatePay(id); reload(); }}>
                      Simulate payment (demo)
                    </button>
                  )}
                </div>
              </>
            )}
          </>
        ) : null}
      </div>
    </div>
  );
}
