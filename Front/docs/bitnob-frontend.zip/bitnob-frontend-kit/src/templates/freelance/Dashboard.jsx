import { Link } from 'react-router-dom';
import { api } from '../../api/client.js';
import { useAsync } from '../../lib/hooks.js';
import { money, dateTime } from '../../lib/format.js';
import { PageHeader, StatCard, Card, BarChart, Badge, Loading, ErrorBox } from '../../components/ui.jsx';

export default function Dashboard() {
  const summary = useAsync(() => api.getSummary());
  const invoices = useAsync(() => api.listInvoices());

  return (
    <>
      <PageHeader
        title="Dashboard"
        subtitle="Your balance, incoming payments and latest invoices"
        action={<Link className="btn" to="/invoices?new=1">+ Create invoice</Link>}
      />
      {summary.error && <ErrorBox error={summary.error} />}
      {summary.loading || !summary.data ? (
        <Loading />
      ) : (
        <div className="stack">
          <div className="grid g4">
            <StatCard label="Balance" value={money(summary.data.balance, summary.data.balance_currency)} hint="Available in your wallet" />
            <StatCard label="Received" value={money(summary.data.received)} hint="Paid invoices" />
            <StatCard label="Pending" value={money(summary.data.pending)} hint="Awaiting payment" />
            <StatCard label="Invoices" value={summary.data.invoice_count} hint="All time" />
          </div>
          <div className="grid g2">
            <Card title="Payments received">
              <BarChart data={summary.data.daily} />
            </Card>
            <Card title="Recent invoices" action={<Link to="/invoices">See all</Link>}>
              {invoices.loading || !invoices.data ? (
                <Loading />
              ) : (
                <table>
                  <tbody>
                    {invoices.data.slice(0, 5).map((i) => (
                      <tr key={i.id}>
                        <td>
                          <b>{i.client}</b>
                          <div className="muted">{dateTime(i.created_at)}</div>
                        </td>
                        <td className="num">{money(i.amount, i.currency)}</td>
                        <td><Badge status={i.status} /></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </Card>
          </div>
        </div>
      )}
    </>
  );
}
