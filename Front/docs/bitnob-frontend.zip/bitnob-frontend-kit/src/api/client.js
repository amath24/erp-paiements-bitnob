import { mockApi } from './mock.js';

// VITE_USE_MOCK=false  ->  talk to the real backend (proxied on /api, see vite.config.js)
const USE_MOCK = import.meta.env.VITE_USE_MOCK !== 'false';

async function http(path, opts = {}) {
  const res = await fetch(`/api${path}`, {
    headers: { 'Content-Type': 'application/json' },
    ...opts,
    body: opts.body ? JSON.stringify(opts.body) : undefined,
  });
  if (!res.ok) throw new Error((await res.text()) || `HTTP ${res.status}`);
  return res.json();
}

// The contract below is what the backend (Person 1) has to expose. See README.md.
const realApi = {
  getSummary: () => http('/summary'),
  listInvoices: () => http('/invoices'),
  getInvoice: (id) => http(`/invoices/${id}`),
  createInvoice: (body) => http('/invoices', { method: 'POST', body }),
  simulatePay: null, // demo-only, the Bitnob webhook updates the status in real mode
  quoteTransfer: (body) => http('/transfers/quote', { method: 'POST', body }),
  listTransfers: () => http('/transfers'),
  createTransfer: (body) => http('/transfers', { method: 'POST', body }),
  listCards: () => http('/cards'),
  createCard: (body) => http('/cards', { method: 'POST', body }),
  fundCard: (id, amount) => http(`/cards/${id}/fund`, { method: 'POST', body: { amount } }),
  listCardTransactions: (id) => http(`/cards/${id}/transactions`),
  createBatch: (body) => http('/bulk_payout', { method: 'POST', body }),
  listBatches: () => http('/batches'),
  getBatch: (id) => http(`/batches/${id}`),
};

export const api = USE_MOCK ? mockApi : realApi;
export const isMock = USE_MOCK;
