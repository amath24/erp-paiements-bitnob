import { COUNTRIES } from '../config.js';

const delay = (ms = 250) => new Promise((r) => setTimeout(r, ms));
const rid = (p) => `${p}_${Math.random().toString(36).slice(2, 8)}`;
const ago = (h) => new Date(Date.now() - h * 3600 * 1000).toISOString();

const db = {
  invoices: [
    { id: 'inv_001', client: 'Acme Ltd', email: 'billing@acme.com', amount: 250, currency: 'USD', description: 'Logo design', status: 'paid', created_at: ago(5) },
    { id: 'inv_002', client: 'Lagos Studio', email: 'hello@lagosstudio.ng', amount: 480, currency: 'USD', description: 'Website landing page', status: 'paid', created_at: ago(30) },
    { id: 'inv_003', client: 'Kofi & Co', email: 'kofi@kofico.gh', amount: 120, currency: 'USD', description: 'Social media pack', status: 'pending', created_at: ago(52) },
    { id: 'inv_004', client: 'Nairobi Tech', email: 'pay@nairobitech.ke', amount: 900, currency: 'USD', description: 'Mobile app prototype', status: 'paid', created_at: ago(76) },
    { id: 'inv_005', client: 'Dakar Foods', email: 'compta@dakarfoods.sn', amount: 310, currency: 'USD', description: 'Packaging design', status: 'expired', created_at: ago(120) },
    { id: 'inv_006', client: 'Acme Ltd', email: 'billing@acme.com', amount: 175, currency: 'USD', description: 'Brand guidelines', status: 'paid', created_at: ago(150) },
  ],
  transfers: [
    { id: 'tr_001', recipient: 'Amina Yusuf', country: 'Nigeria', type: 'mobile_money', account: '+2348012345678', send_amount: 100, receive_amount: 153450, receive_currency: 'NGN', fee: 1.5, status: 'completed', created_at: ago(20) },
    { id: 'tr_002', recipient: 'Kwame Mensah', country: 'Ghana', type: 'bank', account: 'GH-0042-8891', send_amount: 60, receive_amount: 916, receive_currency: 'GHS', fee: 0.9, status: 'processing', created_at: ago(2) },
  ],
  cards: [
    { id: 'card_1', label: 'Marketing', last4: '4821', brand: 'VISA', balance: 320, limit: 1000, status: 'active' },
    { id: 'card_2', label: 'Software', last4: '9034', brand: 'VISA', balance: 85, limit: 300, status: 'active' },
  ],
  cardTx: {
    card_1: [
      { id: 't1', merchant: 'Meta Ads', category: 'Ads', amount: 145.2, created_at: ago(8) },
      { id: 't2', merchant: 'Canva', category: 'Software', amount: 12.99, created_at: ago(30) },
      { id: 't3', merchant: 'Google Ads', category: 'Ads', amount: 98.4, created_at: ago(55) },
      { id: 't4', merchant: 'Bolt', category: 'Transport', amount: 7.1, created_at: ago(70) },
      { id: 't5', merchant: 'Jumia', category: 'Shopping', amount: 54.0, created_at: ago(95) },
    ],
    card_2: [
      { id: 't6', merchant: 'Notion', category: 'Software', amount: 16, created_at: ago(40) },
      { id: 't7', merchant: 'Figma', category: 'Software', amount: 15, created_at: ago(90) },
    ],
  },
  batches: [],
};

// Batch payouts "settle" over time so the tracking page visibly progresses.
function seedBatch() {
  const names = ['Amina Yusuf', 'Kwame Mensah', 'Moussa Diop', 'Grace Wanjiku'];
  const created = Date.now() - 3600 * 1000;
  db.batches.push({
    id: 'batch_demo',
    name: 'Delivery riders – September',
    created_at: new Date(created).toISOString(),
    items: names.map((n, i) => ({
      id: `p_demo_${i}`,
      name: n,
      phone: '+2340000000' + i,
      amount: 20000 + i * 5000,
      currency: i === 1 ? 'GHS' : i === 2 ? 'XOF' : i === 3 ? 'KES' : 'NGN',
      country: ['Nigeria', 'Ghana', 'Senegal', 'Kenya'][i],
      final: i === 3 ? 'failed' : 'success',
      settles_at: created + 1000,
    })),
  });
}
seedBatch();

const withStatus = (b) => {
  const items = b.items.map((it) => ({ ...it, status: Date.now() >= it.settles_at ? it.final : 'processing' }));
  const done = items.filter((i) => i.status !== 'processing').length;
  const status = done < items.length ? 'processing' : items.some((i) => i.status === 'failed') ? 'completed_with_errors' : 'completed';
  return { ...b, items, status, total: items.reduce((s, i) => s + i.amount, 0), count: items.length, success: items.filter((i) => i.status === 'success').length, failed: items.filter((i) => i.status === 'failed').length };
};

const quote = ({ amount, country }) => {
  const c = COUNTRIES[country] ?? { currency: 'USD', rate: 1 };
  const fee = Math.max(0.5, +(amount * 0.015).toFixed(2));
  return { rate: c.rate, fee, receive_currency: c.currency, receive_amount: Math.round((amount - fee) * c.rate * 100) / 100, total: +(Number(amount) + 0).toFixed(2) };
};

export const mockApi = {
  async getSummary() {
    await delay();
    const paid = db.invoices.filter((i) => i.status === 'paid');
    const days = {};
    paid.forEach((i) => {
      const k = new Date(i.created_at).toLocaleDateString('en-GB', { day: '2-digit', month: 'short' });
      days[k] = (days[k] || 0) + i.amount;
    });
    return {
      balance: 1840.5 + paid.reduce((s, i) => s + i.amount, 0) * 0,
      balance_currency: 'USD',
      received: paid.reduce((s, i) => s + i.amount, 0),
      pending: db.invoices.filter((i) => i.status === 'pending').reduce((s, i) => s + i.amount, 0),
      invoice_count: db.invoices.length,
      daily: Object.entries(days).map(([label, value]) => ({ label, value })).reverse(),
    };
  },
  async listInvoices() {
    await delay();
    return [...db.invoices].sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
  },
  async getInvoice(id) {
    await delay(150);
    const inv = db.invoices.find((i) => i.id === id);
    if (!inv) throw new Error('Invoice not found');
    return { ...inv, lightning_invoice: `lnbc${inv.amount}n1pj${inv.id.replace('_', '')}mockqwertyuiopasdfghjklzxcvbnm`, payment_url: `${location.origin}/pay/${inv.id}` };
  },
  async createInvoice(payload) {
    await delay(500);
    const inv = { id: rid('inv'), status: 'pending', created_at: new Date().toISOString(), ...payload, amount: Number(payload.amount) };
    db.invoices.unshift(inv);
    return this.getInvoice(inv.id);
  },
  async simulatePay(id) {
    // Demo only: in real mode the Bitnob webhook flips the status.
    await delay(300);
    const inv = db.invoices.find((i) => i.id === id);
    if (inv) inv.status = 'paid';
    return inv;
  },
  async quoteTransfer(p) {
    await delay(200);
    return quote(p);
  },
  async listTransfers() {
    await delay();
    return [...db.transfers].sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
  },
  async createTransfer(p) {
    await delay(600);
    const q = quote(p);
    const t = { id: rid('tr'), recipient: p.recipient, country: p.country, type: p.type, account: p.account, send_amount: Number(p.amount), receive_amount: q.receive_amount, receive_currency: q.receive_currency, fee: q.fee, status: 'processing', created_at: new Date().toISOString() };
    db.transfers.unshift(t);
    setTimeout(() => (t.status = 'completed'), 12000);
    return t;
  },
  async listCards() {
    await delay();
    return db.cards.map((c) => ({ ...c }));
  },
  async createCard({ label, limit }) {
    await delay(500);
    const c = { id: rid('card'), label, last4: String(Math.floor(1000 + Math.random() * 9000)), brand: 'VISA', balance: 0, limit: Number(limit), status: 'active' };
    db.cards.push(c);
    db.cardTx[c.id] = [];
    return c;
  },
  async fundCard(id, amount) {
    await delay(400);
    const c = db.cards.find((x) => x.id === id);
    c.balance += Number(amount);
    return { ...c };
  },
  async listCardTransactions(id) {
    await delay();
    return db.cardTx[id] ?? [];
  },
  async createBatch({ name, items }) {
    await delay(700);
    const now = Date.now();
    const b = {
      id: rid('batch'),
      name: name || 'Untitled batch',
      created_at: new Date(now).toISOString(),
      items: items.map((it, i) => ({
        id: rid('p'),
        ...it,
        final: (i + 1) % 7 === 0 ? 'failed' : 'success',
        settles_at: now + (i + 1) * 1800,
      })),
    };
    db.batches.unshift(b);
    return withStatus(b);
  },
  async listBatches() {
    await delay();
    return db.batches.map(withStatus).map(({ items, ...rest }) => rest);
  },
  async getBatch(id) {
    await delay(150);
    const b = db.batches.find((x) => x.id === id);
    if (!b) throw new Error('Batch not found');
    return withStatus(b);
  },
};
